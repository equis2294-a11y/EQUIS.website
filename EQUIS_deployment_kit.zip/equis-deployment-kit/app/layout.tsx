import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "EQUIS — Water, with your identity",
  description: "Premium branded bottled water for cafés, hotels, events and businesses in Srinagar, Kashmir."
};
export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}