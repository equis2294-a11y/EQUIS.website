import { NextRequest,NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/supabase";
import { sameOrigin,jsonError } from "@/lib/http";
export const runtime="nodejs";
const schema=z.object({
 customer_name:z.string().trim().min(2).max(100),
 business_name:z.string().trim().max(120).optional().default(""),
 email:z.string().trim().email().max(254),
 phone:z.string().trim().max(25).optional().default(""),
 order_type:z.enum(["enquiry","confirmed"]),
 branding_type:z.enum(["equis","custom"]),
 bottle_size:z.enum(["250 ml","500 ml","1 litre","Discuss options"]),
 quantity:z.coerce.number().int().min(1).max(100000),
 notes:z.string().trim().max(1500).optional().default(""),
 website:z.string().optional().default("")
});
export async function POST(req:NextRequest){
 if(!sameOrigin(req)) return jsonError("Request origin rejected.",403);
 try{
  const body=await req.json();
  const parsed=schema.safeParse(body);
  if(!parsed.success) return jsonError("Please check the form fields.");
  if(parsed.data.website) return NextResponse.json({ok:true,reference:""});
  const d=parsed.data;
  const reference="EQ-"+crypto.randomUUID().slice(0,8).toUpperCase();
  const {error}=await db().from("equis_orders").insert({
   reference,customer_name:d.customer_name,business_name:d.business_name||null,email:d.email,
   phone:d.phone||null,order_type:d.order_type,branding_type:d.branding_type,
   bottle_size:d.bottle_size,quantity:d.quantity,notes:d.notes||null,
   status:"pending_review",payment_status:"not_required"
  });
  if(error){console.error("Order insert failed",error.code);return jsonError("We could not save your request. Please try again later.",503);}
  return NextResponse.json({ok:true,reference},{status:201});
 }catch(e){console.error("Order API error",e instanceof Error?e.message:"unknown");return jsonError("Service is temporarily unavailable.",503);}
}