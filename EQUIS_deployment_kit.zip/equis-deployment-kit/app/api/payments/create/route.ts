import {NextRequest,NextResponse} from "next/server";
import {db} from "@/lib/supabase";
import {sameOrigin,jsonError} from "@/lib/http";
export const runtime="nodejs";
export async function POST(req:NextRequest){
 if(!sameOrigin(req)) return jsonError("Request origin rejected.",403);
 if(process.env.PAYMENTS_MODE!=="test") return jsonError("Payments are locked. Test mode must be explicitly enabled.",403);
 const key=process.env.RAZORPAY_KEY_ID,secret=process.env.RAZORPAY_KEY_SECRET;
 if(!key||!secret||!key.startsWith("rzp_test_")) return jsonError("Test checkout is not configured.",503);
 try{
  const {reference}=await req.json();
  if(typeof reference!=="string"||!/^EQ-[A-F0-9]{8}$/.test(reference)) return jsonError("Invalid order reference.");
  const {data,error}=await db().from("equis_orders").select("id,reference,status,quoted_amount_paise").eq("reference",reference).single();
  if(error||!data) return jsonError("Order not found.",404);
  if(data.status!=="confirmed"||!data.quoted_amount_paise||data.quoted_amount_paise<100) return jsonError("The order must be reviewed, confirmed and given a quote before payment.",409);
  const auth=Buffer.from(`${key}:${secret}`).toString("base64");
  const response=await fetch("https://api.razorpay.com/v1/orders",{method:"POST",headers:{"Authorization":`Basic ${auth}`,"Content-Type":"application/json"},body:JSON.stringify({amount:data.quoted_amount_paise,currency:"INR",receipt:data.reference,notes:{equis_order_id:data.id}})});
  const result=await response.json();
  if(!response.ok){console.error("Razorpay test order error",result.error?.code);return jsonError("Could not start test checkout.",502);}
  await db().from("equis_orders").update({razorpay_order_id:result.id,payment_status:"created"}).eq("id",data.id);
  return NextResponse.json({keyId:key,orderId:result.id,amount:result.amount,currency:result.currency,reference:data.reference});
 }catch(e){console.error("Payment create error",e instanceof Error?e.message:"unknown");return jsonError("Payment service unavailable.",503);}
}