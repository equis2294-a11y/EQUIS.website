-- Run in the Supabase SQL editor for the EQUIS project.
create extension if not exists pgcrypto;
create table if not exists public.equis_orders (
 id uuid primary key default gen_random_uuid(),
 reference text not null unique,
 customer_name text not null,
 business_name text,
 email text not null,
 phone text,
 order_type text not null check (order_type in ('enquiry','confirmed')),
 branding_type text not null check (branding_type in ('equis','custom')),
 bottle_size text not null,
 quantity integer not null check (quantity between 1 and 100000),
 notes text,
 status text not null default 'pending_review' check (status in ('pending_review','quoted','confirmed','in_production','fulfilled','cancelled')),
 quoted_amount_paise bigint,
 payment_status text not null default 'not_required' check (payment_status in ('not_required','created','signature_verified','paid','failed','refunded')),
 razorpay_order_id text unique,
 razorpay_payment_id text,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
create index if not exists equis_orders_created_at_idx on public.equis_orders(created_at desc);
create index if not exists equis_orders_status_idx on public.equis_orders(status);
alter table public.equis_orders enable row level security;
-- No anon/authenticated table policies: all access is through server routes using the service-role key.
revoke all on public.equis_orders from anon, authenticated;
grant all on public.equis_orders to service_role;
