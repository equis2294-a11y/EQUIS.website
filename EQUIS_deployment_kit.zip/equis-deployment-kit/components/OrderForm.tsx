"use client";
import {useState} from "react";
export default function OrderForm(){
 const [state,setState]=useState<"idle"|"sending"|"sent"|"error">("idle");
 const [message,setMessage]=useState("");
 async function submit(e:React.FormEvent<HTMLFormElement>){
  e.preventDefault(); setState("sending"); setMessage("");
  const form=new FormData(e.currentTarget);
  const payload=Object.fromEntries(form.entries());
  try{
   const r=await fetch("/api/orders",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
   const j=await r.json();
   if(!r.ok) throw new Error(j.error||"Unable to submit. Please try again.");
   setState("sent"); setMessage(`Thank you. Your reference is ${j.reference}. This is a request for review, not yet an accepted order.`); e.currentTarget.reset();
  }catch(err){setState("error");setMessage(err instanceof Error?err.message:"Something went wrong.");}
 }
 return <form className="form" onSubmit={submit}>
  <label>Your name<input name="customer_name" required maxLength={100} autoComplete="name"/></label>
  <label>Business / event name<input name="business_name" maxLength={120}/></label>
  <label>Email<input type="email" name="email" required maxLength={254} autoComplete="email"/></label>
  <label>Phone (optional)<input name="phone" type="tel" maxLength={25} autoComplete="tel"/></label>
  <label>Order type<select name="order_type" required defaultValue="enquiry"><option value="enquiry">Enquiry / request a quote</option><option value="confirmed">I am ready to confirm after quotation</option></select></label>
  <label>Branding<select name="branding_type" required><option value="equis">EQUIS branding</option><option value="custom">My own brand / event</option></select></label>
  <div className="two"><label>Preferred size<select name="bottle_size"><option>250 ml</option><option>500 ml</option><option>1 litre</option><option>Discuss options</option></select></label><label>Estimated quantity<input name="quantity" type="number" min="1" max="100000" required/></label></div>
  <label>Delivery area / notes<textarea name="notes" rows={4} maxLength={1500} placeholder="Area in Srinagar, preferred date, artwork details, etc."/></label>
  <div className="trap" aria-hidden="true"><label>Leave blank<input name="website" tabIndex={-1} autoComplete="off"/></label></div>
  <button disabled={state==="sending"}>{state==="sending"?"Sending…":"Send request ↗"}</button>
  <p className="formStatus" aria-live="polite">{message}</p>
  <small>By submitting, you agree that EQUIS may contact you about this request. Do not submit payment-card details or sensitive identity documents here.</small>
 </form>
}