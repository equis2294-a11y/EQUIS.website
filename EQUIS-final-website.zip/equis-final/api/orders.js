const crypto = require('crypto');

function json(res, status, body) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.end(JSON.stringify(body));
}
function getConfig() {
  return { url: process.env.SUPABASE_URL, key: process.env.SUPABASE_SERVICE_ROLE_KEY };
}
function clean(value, max = 2000) {
  if (typeof value !== 'string') return '';
  return value.trim().slice(0, max);
}
async function db(path, options = {}) {
  const { url, key } = getConfig();
  if (!url || !key) throw new Error('Backend is not configured yet');
  const response = await fetch(`${url.replace(/\/$/, '')}/rest/v1/${path}`, {
    ...options,
    headers: {
      apikey: key,
      Authorization: `Bearer ${key}`,
      'Content-Type': 'application/json',
      ...(options.headers || {})
    }
  });
  const text = await response.text();
  if (!response.ok) throw new Error(`Database request failed (${response.status})`);
  return text ? JSON.parse(text) : [];
}
module.exports = async (req, res) => {
  if (req.method === 'POST') {
    try {
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : (req.body || {});
      const customer = clean(body.customer_name, 120);
      if (!customer) return json(res, 400, { error: 'Please enter your name.' });
      const requestType = body.request_type === 'order_request' ? 'order_request' : 'enquiry';
      const email = clean(body.email, 254);
      if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return json(res, 400, { error: 'Please enter a valid email address.' });
      const row = {
        id: crypto.randomUUID(), request_type: requestType,
        customer_name: customer,
        business_name: clean(body.business_name, 160), email,
        phone: clean(body.phone, 40), delivery_area: clean(body.delivery_area, 180),
        request_details: clean(body.request_details, 3000),
        branding: clean(body.branding, 30), brand_name: clean(body.brand_name, 120),
        bottle_size: clean(body.bottle_size, 30), label_style: clean(body.label_style, 40),
        tagline: clean(body.tagline, 120), estimated_quantity: clean(body.estimated_quantity, 50),
        design_notes: clean(body.design_notes, 2000), status: 'new'
      };
      await db('equis_orders', { method: 'POST', headers: { Prefer: 'return=minimal' }, body: JSON.stringify(row) });
      return json(res, 201, { ok: true, id: row.id });
    } catch (error) {
      const message = error.message === 'Backend is not configured yet' ? error.message : 'Could not save your request. Please try again later.';
      return json(res, 503, { error: message });
    }
  }
  if (req.method === 'GET' || req.method === 'PATCH') {
    const token = process.env.ADMIN_ACCESS_TOKEN;
    if (!token || req.headers['x-admin-token'] !== token) return json(res, 401, { error: 'Admin access denied.' });
    try {
      if (req.method === 'GET') {
        const rows = await db('equis_orders?select=id,created_at,request_type,customer_name,business_name,email,phone,delivery_area,bottle_size,estimated_quantity,request_details,status&order=created_at.desc&limit=100');
        return json(res, 200, rows);
      }
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : (req.body || {});
      const id = clean(body.id, 50);
      const status = clean(body.status, 30);
      if (!id || !['new','reviewing','approved','rejected','completed'].includes(status)) return json(res, 400, { error: 'Invalid order ID or status.' });
      await db(`equis_orders?id=eq.${encodeURIComponent(id)}`, { method: 'PATCH', headers: { Prefer: 'return=minimal' }, body: JSON.stringify({ status }) });
      return json(res, 200, { ok: true });
    } catch (error) {
      return json(res, 503, { error: 'Could not update the request.' });
    }
  }
  res.setHeader('Allow', 'GET, POST, PATCH');
  return json(res, 405, { error: 'Method not allowed.' });
};
