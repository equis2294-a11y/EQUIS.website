-- Run this in Supabase SQL Editor for the EQUIS request database.
create extension if not exists pgcrypto;
create table if not exists public.equis_orders (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  request_type text not null check (request_type in ('enquiry','order_request')),
  customer_name text not null,
  business_name text,
  email text,
  phone text,
  delivery_area text,
  request_details text,
  branding text,
  brand_name text,
  bottle_size text,
  label_style text,
  tagline text,
  estimated_quantity text,
  design_notes text,
  status text not null default 'new' check (status in ('new','reviewing','approved','rejected','completed'))
);

-- No public/anonymous table access. The Vercel server function uses the
-- Supabase service-role key, stored only in Vercel environment variables.
alter table public.equis_orders enable row level security;
revoke all on public.equis_orders from anon, authenticated;
